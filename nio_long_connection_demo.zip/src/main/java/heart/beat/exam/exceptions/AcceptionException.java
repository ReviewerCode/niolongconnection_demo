package heart.beat.exam.exceptions;

public class AcceptionException extends AbstractException {
	private static final long serialVersionUID = -7367947111670584494L;

	public AcceptionException(Throwable t) {
		super(t);
	}
}

package heart.beat.exam.exceptions;

public class ConnectionException extends AbstractException {
	private static final long serialVersionUID = 7199861496131767237L;

	public ConnectionException(Throwable t) {
		super(t);
	}
}
